package com.mycompany.samuel_vegar;//ubicacion del archivo en el computador//

import java.util.Scanner;//importar scanner para poder usar teclado//

public class Samuel_Vegar {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        float nota1; //Ingreso de variables//
        float nota2; //float para permitit el uso de decimales//
        float nota3;
        float nota4;
        float nota5;
        float nota6;
        float nota7;
        System.out.print("Ingrese la nota 1:");//muestra en consola lo que el usuario debe colocar//
        nota1=teclado.nextFloat();//Ingreso de datos por parte del usuario//
        System.out.print("Ingrese la nota 2:");
        nota2=teclado.nextFloat();
        System.out.print("Ingrese la nota 3:");
        nota3=teclado.nextFloat();
        System.out.print("Ingrese la nota 4:");
        nota4=teclado.nextFloat();
        System.out.print("Ingrese la nota 5:");
        nota5=teclado.nextFloat();
        System.out.print("Ingrese la nota 6:");
        nota6=teclado.nextFloat();
        System.out.print("Ingrese la nota 7:");
        nota7=teclado.nextFloat();
        
        float corte1 = (float) ((nota1*0.05)+(nota2*0.15));  //Calculo de las notas oingresadas por el porcentaje descrito//
        float corte2 = (float) ((nota3*0.10)+(nota4*0.10));
        float corte3 = (float) ((nota5*0.10)+(nota6*0.20));
        float corte4 = (float) (nota7*0.30);
        
        float semestre = (corte1)+(corte2)+(corte3)+(corte4);//Suma de las notas de todos los cortes//
        
        System.out.printf("Nota definitiva del Corte 1: %.2f%n", corte1);//imprimir resultados//
        System.out.printf("Nota definitiva del Corte 2: %.2f%n", corte2);// %.2f%n para limitar el numero de decimales//
        System.out.printf("Nota definitiva del Corte 3: %.2f%n", corte3);
        System.out.printf("Nota definitiva del Corte 4: %.2f%n", corte4);
        System.out.printf("Nota final del semestre: %.2f%n", semestre);

        teclado.close();//cerrar codigo//
    }
}

